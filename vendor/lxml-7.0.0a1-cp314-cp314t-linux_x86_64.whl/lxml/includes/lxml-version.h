#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "7.0.0.alpha1"
#endif
